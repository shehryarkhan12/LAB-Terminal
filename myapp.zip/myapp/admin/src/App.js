//import logo from './logo.svg';
import { Route, Routes } from "react-router-dom";
import NavBar from './components/Views/NavBar';
import Login from './components/auth/Login';
import Dashboard from './components/Views/Dashboard';
//import './App.css';

function App() {
  return (
       
    <div className="page-heading">
      <div style={{ float: "left", width: "30%" }}>
        <NavBar />
      </div>
      <div style={{ float: "right", width: "65%" }}>
        <h1 style={{ borderBottom: "5px dashed blue" }}>Hello B Section</h1>
        <Routes>
          <Route path="/" element={<Dashboard />}/>
          <Route path="/login" element ={<Login/>}/>
            
            <Route path="*" element={<h1>Page Not Found</h1>} />
          
          
        </Routes>
      </div>
    </div>
       
  );
}

export default App;
