import React from 'react';
import classnames from 'classnames';
import { Pagination, DOTS } from './pagination';

const Pagination = (props) => {

  const {
    PageChange,
    Count,
    siblingCount = 1,
    currentPage,
    pageSize,
    className
  } = props;

  const paginationRng = Pagination({
    currentPage,
    Count,
    siblingCount,
    pageSize
  });

  if (currentPage === 0 || paginationRng.length < 2) {
    return null;
  }

  const Next = () => {
    PageChange(currentPage + 1);
  };

  const Previous = () => {
    PageChange(currentPage - 1);
  };

  let lastPage = paginationRng[paginationRng.length - 1];
  return (
    <ul
      className={classnames('pagination-container', { [className]: className })}
    >
      <li
        className={classnames('pagination-item', {
          disabled: currentPage === 1
        })}
        onClick={Previous}
      >
        <div className="arrow left" />
      </li>
      {paginationRng.map(pageNumber => {
         
        
        if (pageNumber === DOTS) {
          return <li className="pagination-item dots">&#8230;</li>;
        }
		
        return (
          <li
            className={classnames('pagination-item', {
              selected: pageNumber === currentPage
            })}
            onClick={() => PageChange(pageNumber)}
          >
            {pageNumber}
          </li>
        );
      })}
      
      <li
        className={classnames('pagination-item', {
          disabled: currentPage === lastPage
        })}
        onClick={Next}
      >
        <div className="arrow right" />
      </li>
    </ul>
  );
};

export default Pagination;