//import logo from './logo.svg';
import './App.css';
import { Container } from "@mui/material";
import NavBar from './components/Navbar';
import Homepage from './components/Homepage';
import Pagination from './Pagination/Pagination';
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

function App() {
  return (
    <div className="App">
      <NavBar/>
      <Container maxWidth="lg">
      <Routes>
      <Route path="/homepage" element={<Homepage />} />
      <Route path="/pagination" element={<Pagination />}  />

      </Routes>
      </Container>
    </div>
  );
}

export default App;
