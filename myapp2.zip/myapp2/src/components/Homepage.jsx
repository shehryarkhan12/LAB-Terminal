import React from 'react';
const Homepage = () => {
    return ( 
         <h1>This is homepage</h1>
         

     );
}
 
export default Homepage;