import React from "react";
//import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
//import HomeIcon from '@mui/icons-material/Home';
const NavBar = () => {
  
  return (
    <ul>
      
      <li>
        <Link to="/homepage">
        Home
        </Link>
      </li>
      <li>
        <Link to="/pagination">
          Pagination
        </Link>
      </li>
      <li>
        <a href="/">Products</a>
      </li>
      {localStorage.getItem("jwt_access_token") ? (
        <>
          <li>
            <a
              href=""
              onClick={(e) => {
                e.preventDefault();
                localStorage.removeItem("jwt_access_token");
                window.location.reload();
              }}
            >
              Logout
            </a>
          </li>{" "}
        </>
      ) : (
        <>
          <li>
            <Link to="/login">Login</Link>
          </li>
          <li>
            <Link to="/register">Register</Link>
          </li>
        </>
      )}
      
      
    </ul>
  );
};

export default NavBar;
